import org.junit.Test;
import org.junit.jupiter.api.Assertions;



//EIRINI CHRYSIKOPOULOU-3180208

public class ArrayUtilTest3180208 {



    @Test
    public void GivenArrayIsNull(){
        Assertions.assertThrows(IllegalArgumentException.class,()->{
            ArrayUtil.subarray(null,0,0);

        });

    }

    @Test
    public void NegativeStartIndex(){
        int[] array = {1,2,3,4,5};
        Assertions.assertThrows(IllegalArgumentException.class,()->{
            ArrayUtil.subarray(array,-1,0);

        });

    }

    @Test
    public void IllegalEndExclusive(){
        int[] array = {1,2,3,4,5};
        Assertions.assertThrows(IllegalArgumentException.class,()->{
            ArrayUtil.subarray(array,0,10);

        });
    }


    @Test
    public void WrongIndexes(){
        int[] array = {1,2,3,4,5};
        int[] array_new=ArrayUtil.subarray(array,10,5);
        Assertions.assertArrayEquals(new int[0],array_new);
    }
    
    @Test 
    public void TestSubarray(){
        int[] array = {1,2,3,4,5};
        int[] array_new=ArrayUtil.subarray(array,1,4);
        int [] expected_array={2,3,4};
        Assertions.assertArrayEquals(expected_array,array_new);



    }

}
